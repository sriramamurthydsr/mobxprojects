import React, { Component } from 'react';
class App extends Component {
  render() {
    return (
      <h1 className="bg-danger text-center text-warning">Welcome to Mobx by Murthy</h1>
    );
  }
}
export default App;
