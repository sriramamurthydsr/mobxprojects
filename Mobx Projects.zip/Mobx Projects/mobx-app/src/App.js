import React, { Component } from 'react';
import { Provider } from 'mobx-react';
import {  } from 'mobx-react';
class App extends Component {
  render() {
    return (
      <Provider>
        <div >
         <h1 class="bg-success text-center">
           React & Mobx Application
         </h1>
         <div class="container bg-warning">
           <h3>Put your components here</h3>
         </div>
         <footer>
           <h3 class="bg-dark text-info text-center">
             Copyright Reserved to Murthy
           </h3>
         </footer>
        </div>
      </Provider>
    );
  }
}

export default App;
