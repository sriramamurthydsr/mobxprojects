import { shallow } from 'enzyme'
import React from "react"

import TodoList from "../TodoList"

describe("TodoList", function() {
  //don't use an arrow function...preserve the value of "this"
  beforeEach(function() {
    this.store = {
      filteredTodos: [
        {value: "todo1", id: 111, complete: false},
        {value: "todo2", id: 222, complete: false},
        {value: "todo3", id: 333, complete: false},
      ],
      filter: "test",
      createTodo: (val) => {
        this.createTodoCalled = true
        this.todoValue = val
      },
    }
  })

  //tests will go here and receive this.store

})
