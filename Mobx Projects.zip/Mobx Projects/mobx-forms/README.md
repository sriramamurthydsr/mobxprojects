
# Handling react forms with mobx

This is a small app to explain how to tackle forms in React with Mobx.

It is to be used with the [Handling forms in React with Mobx article](https://blog.risingstack.com/handling-react-forms-with-mobx-observables/) on the [RisingStack blog](https://blog.risingstack.com/).


## Following the article
The repo has various tags that correspond to a step in the article.
As we progress in the article, I indicate which tag should be checked out.


## How to run the app

* git clone
* npm install
* npm start
