import React, {Component} from 'react'
import {observer} from 'mobx-react'
import {InputField, asForm} from '../../components'

@observer
class PersonTask extends Component {
  render () {
    const {task, updateProperty} = this.props
    return (
      <div>
        <InputField id={`task-name-${task.id}`} name="name" value={task.name} onChange={updateProperty}/>
        <InputField id={`task-duedate-${task.id}`} name="dueDate" value={task.dueDate} onChange={updateProperty}/>
      </div>
    )
  }
}
export default asForm(PersonTask, 'task')
